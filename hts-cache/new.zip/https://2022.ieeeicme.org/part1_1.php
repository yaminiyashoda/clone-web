
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Start cookieyes banner -->
    <script id="cookieyes" type="text/javascript" src="https://cdn-cookieyes.com/client_data/369e5296de173a66739ac361/script.js"></script>
    <!-- End cookieyes banner -->

    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *Must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>IEEE ICME 2022 | Registration</title>

    <!-- Favicon -->
    <link rel="icon" href="assets/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/css/style_1.css">

    <!-- <script src="twitter-block.js"></script>-->
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner"></div>
            </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Navbar Area -->
        <div class="clever-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <!-- Menu -->
                <nav class="classy-navbar justify-content-between" id="cleverNav" style="background-color: #335b9a;">
                    <!-- Logo -->
                    <a class="nav-brand" href="index.html"><img src="assets/images/ICME2022_logo_sm.png" width="80" alt=""></a>
                </nav>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->


    <!-- ##### Submit for registration Area Start##### -->
    <section class="Submittion-area ">
        <div class="container register-box mb-3">
            <h1 class="text-center" style="font-family: Courier New;">Registration</h1>
            <div class="row">
                <div class="col">
                    <!-- Hero Content -->
                    <h5 class="text-center my-3">
                        <i class="fa fa-user mr-3" style="font-size:36px;color:white; vertical-align: middle;" aria-hidden="true"></i>
                        Part 1, Personal Information
                    </h5>
                </div>
            </div>
        </div>



        <!-- Form for the registration -->
        <form id="form" name="form" method="POST" action="part2_1.php" onsubmit='submitValidate()'>
            <div class="container register-box mb-3">
                <div class="mb-2">
                    <label class="pt-0">Full Name</label>
                    <div class="row">
                        <div class="col-12 col-lg-4 mb-2 mb-lg-0">
                            <input type="text" name="first_name" required>
                            <small>First Name <span class="highlight-text">*</span></small>
                        </div>
                        <div class="col-12 col-lg-4 mb-2 mb-lg-0">
                            <input type="text" name="middle_name">
                            <small>Middle Name</small>
                        </div>
                        <div class="col-12 col-lg-4">
                            <input type="text" name="last_name" required>
                            <small>Last Name <span class="highlight-text">*</span></small>
                        </div>
                    </div>
                </div>


                <div class="mb-2">
                    <label>Organization Name <span class="highlight-text">*</span></label>
                    <input type="text" name="institution" required>
                </div>


                <div class="mb-2">
                    <label>Country <span class="highlight-text">*</span></label>
                    <select id="country" name="country" required>
                        <option value="" disabled selected>Please Select</option>
                        <option value="Afganistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="American Samoa">American Samoa</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Anguilla">Anguilla</option>
                        <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Aruba">Aruba</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bermuda">Bermuda</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bonaire">Bonaire</option>
                        <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Brazil">Brazil</option>
                        <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                        <option value="Brunei">Brunei</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Canary Islands">Canary Islands</option>
                        <option value="Cape Verde">Cape Verde</option>
                        <option value="Cayman Islands">Cayman Islands</option>
                        <option value="Central African Republic">Central African Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Channel Islands">Channel Islands</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Christmas Island">Christmas Island</option>
                        <option value="Cocos Island">Cocos Island</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Congo">Congo</option>
                        <option value="Cook Islands">Cook Islands</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Cote DIvoire">Cote DIvoire</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Curaco">Curacao</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="East Timor">East Timor</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Falkland Islands">Falkland Islands</option>
                        <option value="Faroe Islands">Faroe Islands</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="French Guiana">French Guiana</option>
                        <option value="French Polynesia">French Polynesia</option>
                        <option value="French Southern Ter">French Southern Ter</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Gibraltar">Gibraltar</option>
                        <option value="Great Britain">Great Britain</option>
                        <option value="Greece">Greece</option>
                        <option value="Greenland">Greenland</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guadeloupe">Guadeloupe</option>
                        <option value="Guam">Guam</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Hawaii">Hawaii</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hong Kong">Hong Kong</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="India">India</option>
                        <option value="Iran">Iran</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Isle of Man">Isle of Man</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Korea North">Korea North</option>
                        <option value="Korea Sout">Korea South</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Laos">Laos</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libya">Libya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Macau">Macau</option>
                        <option value="Macedonia">Macedonia</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Martinique">Martinique</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius">Mauritius</option>
                        <option value="Mayotte">Mayotte</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Midway Islands">Midway Islands</option>
                        <option value="Moldova">Moldova</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Myanmar">Myanmar</option>
                        <option value="Nambia">Nambia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherland Antilles">Netherland Antilles</option>
                        <option value="Netherlands">Netherlands (Holland, Europe)</option>
                        <option value="Nevis">Nevis</option>
                        <option value="New Caledonia">New Caledonia</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Niue">Niue</option>
                        <option value="Norfolk Island">Norfolk Island</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Palau Island">Palau Island</option>
                        <option value="Palestine">Palestine</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua New Guinea">Papua New Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Phillipines">Philippines</option>
                        <option value="Pitcairn Island">Pitcairn Island</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Puerto Rico">Puerto Rico</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Republic of Montenegro">Republic of Montenegro</option>
                        <option value="Republic of Serbia">Republic of Serbia</option>
                        <option value="Reunion">Reunion</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russia</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="St Barthelemy">St Barthelemy</option>
                        <option value="St Eustatius">St Eustatius</option>
                        <option value="St Helena">St Helena</option>
                        <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                        <option value="St Lucia">St Lucia</option>
                        <option value="St Maarten">St Maarten</option>
                        <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                        <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                        <option value="Saipan">Saipan</option>
                        <option value="Samoa">Samoa</option>
                        <option value="Samoa American">Samoa American</option>
                        <option value="San Marino">San Marino</option>
                        <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra Leone">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="Somalia">Somalia</option>
                        <option value="South Africa">South Africa</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Swaziland">Swaziland</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syria</option>
                        <option value="Tahiti">Tahiti</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Togo">Togo</option>
                        <option value="Tokelau">Tokelau</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                        <option value="Tuvalu">Tuvalu</option>
                        <option value="Uganda">Uganda</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Erimates">United Arab Emirates</option>
                        <option value="United States of America">United States of America</option>
                        <option value="Uraguay">Uruguay</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Vatican City State">Vatican City State</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                        <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                        <option value="Wake Island">Wake Island</option>
                        <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Zaire">Zaire</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>
                </div>


                <div class="mb-2">
                    <label>Postal Address</label>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="text" name="addr1" required>
                            <small>Address Line 1 <span class="highlight-text">*</span></small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="text" name="addr2">
                            <small>Address Line 2</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="text" name="addr3">
                            <small>Address Line 3</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="text" name="city" required>
                            <small>City/Locality <span class="highlight-text">*</span></small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12  mb-3">
                            <input type="text" name="state" required>
                            <small>State/Province/Territory <span class="highlight-text">*</span></small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <input type="text" name="postal_code" required>
                            <small>ZIP/Postal code <span class="highlight-text">*</span></small>
                        </div>
                    </div>
                </div>
            </div>


            <div class="container register-box mb-3">
                <div class="mb-2">
                    <label class="pt-0">Email <span class="highlight-text">*</span></label>
                    <input type="email" name="email" placeholder="example@example.com" required>
                </div>


                <div class="mb-2">
                    <label>Password <span class="highlight-text">*</span></label>
                    <input type="password" name="password" required oninput='if (this.value.length < 8) {this.classList.add("is-invalid")} else {this.classList.remove("is-invalid")} oninputValidate();'>
                    <p id="test"></p>
                    <small>Must be at least 8 characters</small>
                </div>


                <div class="mb-2">
                    <label>Confirm Password <span class="highlight-text">*</span></label>
                    <input type="password" name="password_confirm" required oninput='oninputValidate()'>
                    <p id="not-match-msg" style="display: none;">The password is not match.</p>
                </div>
            </div>


            <div class="container register-box mb-3">
                <div class="mb-2">
                    <label class="pt-0">
                        Registration Type (Membership) <span class="highlight-text">*</span>
                        <p>The registration type can <b>NOT</b> be changed after the submission, please be careful to select it.</p>
                    </label>
                    <select id="user_type" name="user_type" onchange="memberIdInput();" required>
                        <option value="" disabled selected>Please Select</option>
                        <option value="1">SPS Member (Physical or Author)</option>
                        <option value="2">IEEE Member (Physical or Author)</option>
                        <option value="3">Non-Member (Physical or Author)</option>
                        <option value="4">Student (Physical)</option>
                        <option value="5">Other Attendee (Virtual)</option>
                    </select>
                    <input id="member_id" type="text" placeholder="Member ID" name="member_id" class="mt-3" style="display: none">
                </div>


                <div id="paper-id-section" class="mb-2" style="display: none;">
                    <label>
                        Paper ID
                        <p>
                            Please select the paper ID and click '+' button to add into registration list.
                        </p>
                        <p class="normal">
                            For non-author attendees, you can skip this field.
                        </p>
                        <p class="normal">
                            If the ID are not able to be chosen, it means the paper has already been registered.
                        </p>
                    </label>
                    <div class="row">
                        <button class="col-3 col-lg-1 ml-3 my-0" onclick="addPaperId()">+</button>
                        <div class="col-7 col-lg-6">
                            <select class="custom-select" name="select_id" id="select_id">
                                <option value=1w class=text-muted disabled>1w</option><option value=2w class=text-muted disabled>2w</option><option value=3 class=text-muted disabled>3</option><option value=3w class=text-muted disabled>3w</option><option value=4 class=text-muted disabled>4</option><option value=5>5</option><option value=5w class=text-muted disabled>5w</option><option value=9 class=text-muted disabled>9</option><option value=13w class=text-muted disabled>13w</option><option value=14w class=text-muted disabled>14w</option><option value=20 class=text-muted disabled>20</option><option value=20w class=text-muted disabled>20w</option><option value=22 class=text-muted disabled>22</option><option value=22w class=text-muted disabled>22w</option><option value=24w class=text-muted disabled>24w</option><option value=25 class=text-muted disabled>25</option><option value=26w class=text-muted disabled>26w</option><option value=27w class=text-muted disabled>27w</option><option value=28w class=text-muted disabled>28w</option><option value=32w class=text-muted disabled>32w</option><option value=34 class=text-muted disabled>34</option><option value=35 class=text-muted disabled>35</option><option value=36 class=text-muted disabled>36</option><option value=36w class=text-muted disabled>36w</option><option value=38w class=text-muted disabled>38w</option><option value=40w class=text-muted disabled>40w</option><option value=42w class=text-muted disabled>42w</option><option value=49 class=text-muted disabled>49</option><option value=49w>49w</option><option value=50w>50w</option><option value=51w class=text-muted disabled>51w</option><option value=53w>53w</option><option value=54w class=text-muted disabled>54w</option><option value=55 class=text-muted disabled>55</option><option value=55w class=text-muted disabled>55w</option><option value=56 class=text-muted disabled>56</option><option value=56w>56w</option><option value=57 class=text-muted disabled>57</option><option value=58w>58w</option><option value=59 class=text-muted disabled>59</option><option value=59w class=text-muted disabled>59w</option><option value=60>60</option><option value=61w>61w</option><option value=62w class=text-muted disabled>62w</option><option value=63>63</option><option value=63w class=text-muted disabled>63w</option><option value=66 class=text-muted disabled>66</option><option value=69 class=text-muted disabled>69</option><option value=70 class=text-muted disabled>70</option><option value=70w>70w</option><option value=76w class=text-muted disabled>76w</option><option value=81 class=text-muted disabled>81</option><option value=81w>81w</option><option value=82 class=text-muted disabled>82</option><option value=83w class=text-muted disabled>83w</option><option value=85w>85w</option><option value=86w class=text-muted disabled>86w</option><option value=87w class=text-muted disabled>87w</option><option value=89 class=text-muted disabled>89</option><option value=92w class=text-muted disabled>92w</option><option value=94w>94w</option><option value=95w class=text-muted disabled>95w</option><option value=96w>96w</option><option value=100 class=text-muted disabled>100</option><option value=101 class=text-muted disabled>101</option><option value=101w class=text-muted disabled>101w</option><option value=102w>102w</option><option value=103w class=text-muted disabled>103w</option><option value=104 class=text-muted disabled>104</option><option value=105 class=text-muted disabled>105</option><option value=110 class=text-muted disabled>110</option><option value=115 class=text-muted disabled>115</option><option value=121 class=text-muted disabled>121</option><option value=141 class=text-muted disabled>141</option><option value=142 class=text-muted disabled>142</option><option value=143 class=text-muted disabled>143</option><option value=146 class=text-muted disabled>146</option><option value=149 class=text-muted disabled>149</option><option value=150 class=text-muted disabled>150</option><option value=158 class=text-muted disabled>158</option><option value=163 class=text-muted disabled>163</option><option value=171 class=text-muted disabled>171</option><option value=172 class=text-muted disabled>172</option><option value=185 class=text-muted disabled>185</option><option value=186 class=text-muted disabled>186</option><option value=188 class=text-muted disabled>188</option><option value=209 class=text-muted disabled>209</option><option value=215 class=text-muted disabled>215</option><option value=216 class=text-muted disabled>216</option><option value=219 class=text-muted disabled>219</option><option value=223 class=text-muted disabled>223</option><option value=228 class=text-muted disabled>228</option><option value=229 class=text-muted disabled>229</option><option value=245 class=text-muted disabled>245</option><option value=250 class=text-muted disabled>250</option><option value=257 class=text-muted disabled>257</option><option value=267 class=text-muted disabled>267</option><option value=279 class=text-muted disabled>279</option><option value=284 class=text-muted disabled>284</option><option value=291 class=text-muted disabled>291</option><option value=303 class=text-muted disabled>303</option><option value=313>313</option><option value=318 class=text-muted disabled>318</option><option value=327 class=text-muted disabled>327</option><option value=333 class=text-muted disabled>333</option><option value=336 class=text-muted disabled>336</option><option value=341 class=text-muted disabled>341</option><option value=344 class=text-muted disabled>344</option><option value=348 class=text-muted disabled>348</option><option value=349>349</option><option value=350 class=text-muted disabled>350</option><option value=351 class=text-muted disabled>351</option><option value=353 class=text-muted disabled>353</option><option value=355 class=text-muted disabled>355</option><option value=358 class=text-muted disabled>358</option><option value=362 class=text-muted disabled>362</option><option value=367 class=text-muted disabled>367</option><option value=370 class=text-muted disabled>370</option><option value=371 class=text-muted disabled>371</option><option value=374 class=text-muted disabled>374</option><option value=378 class=text-muted disabled>378</option><option value=393 class=text-muted disabled>393</option><option value=394 class=text-muted disabled>394</option><option value=396 class=text-muted disabled>396</option><option value=398>398</option><option value=399 class=text-muted disabled>399</option><option value=401 class=text-muted disabled>401</option><option value=409 class=text-muted disabled>409</option><option value=413 class=text-muted disabled>413</option><option value=415 class=text-muted disabled>415</option><option value=418 class=text-muted disabled>418</option><option value=419 class=text-muted disabled>419</option><option value=426 class=text-muted disabled>426</option><option value=429 class=text-muted disabled>429</option><option value=430 class=text-muted disabled>430</option><option value=432 class=text-muted disabled>432</option><option value=436 class=text-muted disabled>436</option><option value=440 class=text-muted disabled>440</option><option value=441 class=text-muted disabled>441</option><option value=444 class=text-muted disabled>444</option><option value=447 class=text-muted disabled>447</option><option value=448 class=text-muted disabled>448</option><option value=461 class=text-muted disabled>461</option><option value=465 class=text-muted disabled>465</option><option value=472 class=text-muted disabled>472</option><option value=485 class=text-muted disabled>485</option><option value=486 class=text-muted disabled>486</option><option value=489 class=text-muted disabled>489</option><option value=492 class=text-muted disabled>492</option><option value=499 class=text-muted disabled>499</option><option value=506 class=text-muted disabled>506</option><option value=507 class=text-muted disabled>507</option><option value=512 class=text-muted disabled>512</option><option value=515 class=text-muted disabled>515</option><option value=519 class=text-muted disabled>519</option><option value=521 class=text-muted disabled>521</option><option value=523 class=text-muted disabled>523</option><option value=524 class=text-muted disabled>524</option><option value=526 class=text-muted disabled>526</option><option value=537 class=text-muted disabled>537</option><option value=542>542</option><option value=544 class=text-muted disabled>544</option><option value=546 class=text-muted disabled>546</option><option value=548 class=text-muted disabled>548</option><option value=551 class=text-muted disabled>551</option><option value=561 class=text-muted disabled>561</option><option value=572 class=text-muted disabled>572</option><option value=573 class=text-muted disabled>573</option><option value=574 class=text-muted disabled>574</option><option value=576 class=text-muted disabled>576</option><option value=582 class=text-muted disabled>582</option><option value=594 class=text-muted disabled>594</option><option value=605>605</option><option value=618 class=text-muted disabled>618</option><option value=622 class=text-muted disabled>622</option><option value=624 class=text-muted disabled>624</option><option value=634 class=text-muted disabled>634</option><option value=637 class=text-muted disabled>637</option><option value=639>639</option><option value=641 class=text-muted disabled>641</option><option value=644 class=text-muted disabled>644</option><option value=645 class=text-muted disabled>645</option><option value=663 class=text-muted disabled>663</option><option value=668 class=text-muted disabled>668</option><option value=673>673</option><option value=678 class=text-muted disabled>678</option><option value=680>680</option><option value=686 class=text-muted disabled>686</option><option value=687 class=text-muted disabled>687</option><option value=689 class=text-muted disabled>689</option><option value=699 class=text-muted disabled>699</option><option value=700 class=text-muted disabled>700</option><option value=701 class=text-muted disabled>701</option><option value=703 class=text-muted disabled>703</option><option value=719 class=text-muted disabled>719</option><option value=722 class=text-muted disabled>722</option><option value=725 class=text-muted disabled>725</option><option value=735 class=text-muted disabled>735</option><option value=747 class=text-muted disabled>747</option><option value=748 class=text-muted disabled>748</option><option value=749 class=text-muted disabled>749</option><option value=750 class=text-muted disabled>750</option><option value=751 class=text-muted disabled>751</option><option value=754 class=text-muted disabled>754</option><option value=756 class=text-muted disabled>756</option><option value=773 class=text-muted disabled>773</option><option value=774 class=text-muted disabled>774</option><option value=776>776</option><option value=777 class=text-muted disabled>777</option><option value=784 class=text-muted disabled>784</option><option value=787 class=text-muted disabled>787</option><option value=789 class=text-muted disabled>789</option><option value=792>792</option><option value=793>793</option><option value=804 class=text-muted disabled>804</option><option value=808 class=text-muted disabled>808</option><option value=810 class=text-muted disabled>810</option><option value=815 class=text-muted disabled>815</option><option value=817 class=text-muted disabled>817</option><option value=826>826</option><option value=833 class=text-muted disabled>833</option><option value=837 class=text-muted disabled>837</option><option value=839 class=text-muted disabled>839</option><option value=841 class=text-muted disabled>841</option><option value=842 class=text-muted disabled>842</option><option value=844 class=text-muted disabled>844</option><option value=858 class=text-muted disabled>858</option><option value=867 class=text-muted disabled>867</option><option value=871 class=text-muted disabled>871</option><option value=879>879</option><option value=881 class=text-muted disabled>881</option><option value=884 class=text-muted disabled>884</option><option value=885 class=text-muted disabled>885</option><option value=887 class=text-muted disabled>887</option><option value=888 class=text-muted disabled>888</option><option value=897 class=text-muted disabled>897</option><option value=898>898</option><option value=903 class=text-muted disabled>903</option><option value=908>908</option><option value=909 class=text-muted disabled>909</option><option value=918 class=text-muted disabled>918</option><option value=927 class=text-muted disabled>927</option><option value=935 class=text-muted disabled>935</option><option value=939 class=text-muted disabled>939</option><option value=944 class=text-muted disabled>944</option><option value=945 class=text-muted disabled>945</option><option value=946 class=text-muted disabled>946</option><option value=949 class=text-muted disabled>949</option><option value=956 class=text-muted disabled>956</option><option value=957 class=text-muted disabled>957</option><option value=960 class=text-muted disabled>960</option><option value=963>963</option><option value=966 class=text-muted disabled>966</option><option value=968 class=text-muted disabled>968</option><option value=969 class=text-muted disabled>969</option><option value=970 class=text-muted disabled>970</option><option value=971 class=text-muted disabled>971</option><option value=976 class=text-muted disabled>976</option><option value=977 class=text-muted disabled>977</option><option value=979 class=text-muted disabled>979</option><option value=980 class=text-muted disabled>980</option><option value=984 class=text-muted disabled>984</option><option value=986 class=text-muted disabled>986</option><option value=994 class=text-muted disabled>994</option><option value=995 class=text-muted disabled>995</option><option value=1001 class=text-muted disabled>1001</option><option value=1003 class=text-muted disabled>1003</option><option value=1007 class=text-muted disabled>1007</option><option value=1014 class=text-muted disabled>1014</option><option value=1015>1015</option><option value=1016 class=text-muted disabled>1016</option><option value=1027 class=text-muted disabled>1027</option><option value=1029 class=text-muted disabled>1029</option><option value=1031 class=text-muted disabled>1031</option><option value=1037 class=text-muted disabled>1037</option><option value=1040 class=text-muted disabled>1040</option><option value=1049 class=text-muted disabled>1049</option><option value=1055 class=text-muted disabled>1055</option><option value=1059 class=text-muted disabled>1059</option><option value=1062 class=text-muted disabled>1062</option><option value=1066>1066</option><option value=1067 class=text-muted disabled>1067</option><option value=1074 class=text-muted disabled>1074</option><option value=1077 class=text-muted disabled>1077</option><option value=1078 class=text-muted disabled>1078</option><option value=1079 class=text-muted disabled>1079</option><option value=1080 class=text-muted disabled>1080</option><option value=1081 class=text-muted disabled>1081</option><option value=1087 class=text-muted disabled>1087</option><option value=1092 class=text-muted disabled>1092</option><option value=1095 class=text-muted disabled>1095</option><option value=1100 class=text-muted disabled>1100</option><option value=1101 class=text-muted disabled>1101</option><option value=1104 class=text-muted disabled>1104</option><option value=1105 class=text-muted disabled>1105</option><option value=1110 class=text-muted disabled>1110</option><option value=1113 class=text-muted disabled>1113</option><option value=1114 class=text-muted disabled>1114</option><option value=1115 class=text-muted disabled>1115</option><option value=1116 class=text-muted disabled>1116</option><option value=1119 class=text-muted disabled>1119</option><option value=1122 class=text-muted disabled>1122</option><option value=1125 class=text-muted disabled>1125</option><option value=1129 class=text-muted disabled>1129</option><option value=1139 class=text-muted disabled>1139</option><option value=1155 class=text-muted disabled>1155</option><option value=1158 class=text-muted disabled>1158</option><option value=1162 class=text-muted disabled>1162</option><option value=1165 class=text-muted disabled>1165</option><option value=1168 class=text-muted disabled>1168</option><option value=1175 class=text-muted disabled>1175</option><option value=1177 class=text-muted disabled>1177</option><option value=1178 class=text-muted disabled>1178</option><option value=1180 class=text-muted disabled>1180</option><option value=1182 class=text-muted disabled>1182</option><option value=1194 class=text-muted disabled>1194</option><option value=1209 class=text-muted disabled>1209</option><option value=1210>1210</option><option value=1211 class=text-muted disabled>1211</option><option value=1216 class=text-muted disabled>1216</option><option value=1219 class=text-muted disabled>1219</option><option value=1220 class=text-muted disabled>1220</option><option value=1222 class=text-muted disabled>1222</option><option value=1228 class=text-muted disabled>1228</option><option value=1229 class=text-muted disabled>1229</option><option value=1231 class=text-muted disabled>1231</option><option value=1237 class=text-muted disabled>1237</option><option value=1238 class=text-muted disabled>1238</option><option value=1239 class=text-muted disabled>1239</option><option value=1240 class=text-muted disabled>1240</option><option value=1251 class=text-muted disabled>1251</option><option value=1264 class=text-muted disabled>1264</option><option value=1269 class=text-muted disabled>1269</option><option value=1275>1275</option><option value=1277 class=text-muted disabled>1277</option><option value=1279 class=text-muted disabled>1279</option><option value=1280 class=text-muted disabled>1280</option><option value=1290 class=text-muted disabled>1290</option><option value=1291 class=text-muted disabled>1291</option><option value=1292 class=text-muted disabled>1292</option><option value=1294 class=text-muted disabled>1294</option><option value=1296 class=text-muted disabled>1296</option><option value=1299 class=text-muted disabled>1299</option><option value=1303 class=text-muted disabled>1303</option><option value=1305 class=text-muted disabled>1305</option><option value=1306 class=text-muted disabled>1306</option><option value=1307 class=text-muted disabled>1307</option><option value=1309 class=text-muted disabled>1309</option><option value=1313 class=text-muted disabled>1313</option><option value=1315 class=text-muted disabled>1315</option><option value=1316 class=text-muted disabled>1316</option><option value=1320 class=text-muted disabled>1320</option><option value=1322 class=text-muted disabled>1322</option><option value=1323 class=text-muted disabled>1323</option><option value=1325 class=text-muted disabled>1325</option><option value=1326 class=text-muted disabled>1326</option><option value=1327 class=text-muted disabled>1327</option><option value=1328 class=text-muted disabled>1328</option><option value=1329 class=text-muted disabled>1329</option><option value=1332 class=text-muted disabled>1332</option><option value=1335 class=text-muted disabled>1335</option><option value=1338 class=text-muted disabled>1338</option><option value=1341 class=text-muted disabled>1341</option><option value=1342 class=text-muted disabled>1342</option><option value=1343>1343</option><option value=1356 class=text-muted disabled>1356</option><option value=1358 class=text-muted disabled>1358</option><option value=1359 class=text-muted disabled>1359</option><option value=1361 class=text-muted disabled>1361</option><option value=1362 class=text-muted disabled>1362</option><option value=1363 class=text-muted disabled>1363</option><option value=1377 class=text-muted disabled>1377</option><option value=1379>1379</option><option value=1383 class=text-muted disabled>1383</option><option value=1385 class=text-muted disabled>1385</option><option value=1386>1386</option><option value=1392 class=text-muted disabled>1392</option><option value=1394 class=text-muted disabled>1394</option><option value=1399 class=text-muted disabled>1399</option><option value=1401 class=text-muted disabled>1401</option><option value=1402 class=text-muted disabled>1402</option><option value=1405 class=text-muted disabled>1405</option><option value=1415 class=text-muted disabled>1415</option><option value=1422>1422</option><option value=1430 class=text-muted disabled>1430</option><option value=1432 class=text-muted disabled>1432</option><option value=1436 class=text-muted disabled>1436</option><option value=1439 class=text-muted disabled>1439</option><option value=1456 class=text-muted disabled>1456</option><option value=1463 class=text-muted disabled>1463</option><option value=1467 class=text-muted disabled>1467</option><option value=1475 class=text-muted disabled>1475</option><option value=1482 class=text-muted disabled>1482</option><option value=1485 class=text-muted disabled>1485</option><option value=1486 class=text-muted disabled>1486</option><option value=1488 class=text-muted disabled>1488</option><option value=1495 class=text-muted disabled>1495</option><option value=1502 class=text-muted disabled>1502</option><option value=1516 class=text-muted disabled>1516</option><option value=1519 class=text-muted disabled>1519</option><option value=1520 class=text-muted disabled>1520</option><option value=1521 class=text-muted disabled>1521</option><option value=1526>1526</option><option value=1529 class=text-muted disabled>1529</option><option value=1530 class=text-muted disabled>1530</option><option value=1531 class=text-muted disabled>1531</option><option value=1532 class=text-muted disabled>1532</option><option value=1539 class=text-muted disabled>1539</option><option value=1546 class=text-muted disabled>1546</option><option value=1552 class=text-muted disabled>1552</option><option value=1554 class=text-muted disabled>1554</option><option value=1560 class=text-muted disabled>1560</option><option value=1565 class=text-muted disabled>1565</option><option value=1566 class=text-muted disabled>1566</option><option value=1568 class=text-muted disabled>1568</option><option value=1574 class=text-muted disabled>1574</option><option value=1579 class=text-muted disabled>1579</option><option value=1585 class=text-muted disabled>1585</option><option value=1587 class=text-muted disabled>1587</option><option value=1589 class=text-muted disabled>1589</option><option value=1591 class=text-muted disabled>1591</option><option value=1604 class=text-muted disabled>1604</option><option value=1625 class=text-muted disabled>1625</option><option value=1690 class=text-muted disabled>1690</option><option value=1691 class=text-muted disabled>1691</option><option value=1694 class=text-muted disabled>1694</option><option value=1695 class=text-muted disabled>1695</option><option value=1696>1696</option><option value=1698>1698</option><option value=1699 class=text-muted disabled>1699</option><option value=1700 class=text-muted disabled>1700</option><option value=1702>1702</option><option value=1704 class=text-muted disabled>1704</option><option value=1705 class=text-muted disabled>1705</option><option value=1706 class=text-muted disabled>1706</option><option value=1708 class=text-muted disabled>1708</option><option value=1709 class=text-muted disabled>1709</option><option value=1710 class=text-muted disabled>1710</option><option value=1711>1711</option><option value=1712 class=text-muted disabled>1712</option><option value=1716 class=text-muted disabled>1716</option><option value=1718>1718</option><option value=1719 class=text-muted disabled>1719</option><option value=1726 class=text-muted disabled>1726</option><option value=1727>1727</option><option value=1728 class=text-muted disabled>1728</option><option value=1730 class=text-muted disabled>1730</option><option value=1732>1732</option><option value=1733>1733</option><option value=1736 class=text-muted disabled>1736</option><option value=1737 class=text-muted disabled>1737</option>                            </select>
                        </div>
                    </div>
                    <hr style="border-top: 1px solid white">
                    <p class="normal">Selected Paper ID</p>
                    <small>You can also click '-' button to delete the paper ID which you are not going to register.</small>
                    <div id="regis_paper_list"></div>
                    <input type="text" name="paper_id" id="paper_id" style="display: none;">
                    <!-- <input type="text" name="paper_id" placeholder="ex: 123;456;789"> -->
                </div>
            </div>


            <div class="container register-box">
                <div class="mb-2">
                    <label class="pt-0">
                        IEEE Terms and Conditions & Privacy Policy / ICME2022 Privacy Policy <span class="highlight-text">*</span>
                        <p class="normal"><b>Acceptance of IEEE Policies are required to register for this event.</b></p>
                        <p class="normal">By submitting your registration details, you acknowledge that:</p>
                    </label>
                    <div class="form-check">
                        <div class="mb-2">
                            <input class="form-check-input" type="checkbox" name="privacy-1" id="privacy-1" required>
                            <label class="form-check-label pt-0" style="font-size: 14px; font-weight: normal;" for="privacy-1">
                                I have read and agree to <a href="https://www.ieee.org/security-privacy.html" target="_blank">IEEE’s Privacy Policy</a>
                            </label>
                        </div>

                        <div class="mb-2">
                            <input class="form-check-input" type="checkbox" name="privacy-2" id="privacy-2" required>
                            <label class="form-check-label pt-0" style="font-size: 14px; font-weight: normal;" for="privacy-2">
                                I have read and agree to the <a href="https://www.ieee.org/conferences/event-terms-and-conditions.html" target="_blank">IEEE Event Terms and Conditions</a>
                            </label>
                        </div>

                        <div class="mb-0">
                            <input class="form-check-input" type="checkbox" name="privacy-3" id="privacy-3" required>
                            <label class="form-check-label pt-0" style="font-size: 14px; font-weight: normal;" for="privacy-3">
                                I have read and agree to <a href="https://www.termsfeed.com/live/555e872d-9a61-4534-aa46-c089bcad49fa" target="_blank">ICME2022 Privacy Policy</a>
                            </label>
                        </div>
                    </div>
                </div>


                <input class="mt-5" type="submit" value="Next">


                <p class="normal text-center mt-3">
                    Already Registered? <a href="virtual">Login</a>
                </p>
            </div>
        </form>

        <script>
            function submitValidate() {
                let a = document.getElementsByName("password");
                let b = document.getElementsByName("password_confirm");

                if (a[0].value.length < 8) {
                    event.preventDefault();
                    event.stopPropagation();
                    window.alert("Your password must be at least 8 characters!")
                    return false;
                }

                if (a[0].value != b[0].value) {
                    event.preventDefault();
                    event.stopPropagation();
                    window.alert("Your password confirmation does not match! Please check again.");
                    return false;
                }

                collectPaperId();
            }

            function oninputValidate() {
                let a = document.getElementsByName("password");
                let b = document.getElementsByName("password_confirm");
                let msg = document.getElementById("not-match-msg");

                if (a[0].value != b[0].value) {
                    b[0].classList.add("is-invalid");
                    msg.style.display = "block"
                } else {
                    b[0].classList.remove("is-invalid");
                    msg.style.display = "none";
                }
            }

            function addPaperId() {
                event.preventDefault();

                let paperIdList = document.getElementById('regis_paper_list');
                let selectedId = document.getElementById('select_id').value;

                if (!document.getElementById(selectedId)) {
                    let block = document.createElement('div');
                    block.id = selectedId;
                    block.classList.add('row', 'my-3')

                    let element = document.createElement('p');
                    element.innerText = selectedId;
                    element.classList.add('normal', 'font-weight-bold', 'col-7', 'col-lg-6', 'pl-4');

                    let deleteBtn = document.createElement('button');
                    deleteBtn.innerText = '-';
                    deleteBtn.setAttribute('onclick', 'deletePaperId(this);');
                    deleteBtn.classList.add('col-3', 'col-lg-1', 'ml-3', 'my-0');

                    block.appendChild(deleteBtn);
                    block.appendChild(element);

                    paperIdList.appendChild(block);
                }
            }

            function deletePaperId(e) {
                event.preventDefault();
                document.getElementById('regis_paper_list').removeChild(document.getElementById(e.parentElement.id))
            }

            function collectPaperId() {
                let userType = document.getElementById('user_type').value;

                let submitPaperId = document.getElementById('paper_id');
                submitPaperId.value = '';

                if ((userType == '1') || (userType == '2') || (userType == '3')) {
                    let idList = document.getElementById('regis_paper_list').children;
                    for (let i = 0; i < idList.length; i++) {
                        submitPaperId.value += idList[i].id;
                        if (i != idList.length - 1) {
                            submitPaperId.value += ';'
                        }
                    }
                }
            }

            function memberIdInput() {
                let userType = document.getElementById('user_type').value;
                let memberId = document.getElementById('member_id');
                let papedIdSection = document.getElementById('paper-id-section');

                if ((userType == '1') || (userType == '2')) {
                    memberId.style.display = 'block';
                    memberId.required = true;
                    papedIdSection.style.display = 'block';
                } else if (userType == '3') {
                    memberId.style.display = 'none';
                    memberId.required = false;
                    papedIdSection.style.display = 'block';
                } else {
                    memberId.style.display = 'none';
                    memberId.required = false;
                    papedIdSection.style.display = 'none';
                }
            }
        </script>
        </div>
    </section>

    <!-- ##### Submit for registration Area End##### -->


    <!-- ##### Sponsors Page Area Start ##### -->
    <!-- <script src="assets/js/partials/sponsers.js"></script> -->
    <!-- ##### Sponsors Page Area End ##### -->


    <!-- ##### Footer Area Start ##### -->
    <script src="assets/js/partials/regis_footer.js"></script>
    <!-- ##### Footer Area End ##### -->


    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="assets/js/registration/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="assets/js/registration/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="assets/js/registration/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="assets/js/registration/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="assets/js/registration/active.js"></script><a id="scrollUp" href="#top" style="display: none; position: fixed; z-index: 2147483647;"><i class="fa fa-angle-up"></i></a>


</body>

</html>